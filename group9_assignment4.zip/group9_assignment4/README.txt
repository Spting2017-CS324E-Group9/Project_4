﻿1. Ensure that the sound library is installed. 
2. Open ‘group9_assignment4.pde’
3. Click ‘run’ to display the animation.