1. Open the ‘pde’ file
2. Click Run
3. Move the mouse to control the shepherd 
   and keep the wolf away from the sheep